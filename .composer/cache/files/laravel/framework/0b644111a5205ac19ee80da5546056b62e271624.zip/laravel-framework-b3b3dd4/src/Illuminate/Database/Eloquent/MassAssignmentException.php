<?php

namespace Illuminate\Database\Eloquent;

use RuntimeException;

class MassAssignmentException extends RuntimeException
{
    //
}
